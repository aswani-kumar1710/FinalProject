package com.capgemini.Validation.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PDetails {

	@Id
	@Column(name="c_name")
	private String name;
	@Column(name="c_age")
	private int age;
	@Column(name="c_email")
	private String email;
	@Column(name="c_phoneNo")
	private long phoneNo;
	@Column(name="c_address")
	private String address;
	@Column(name="c_gender")
	private String gender;
	
	
	
	public PDetails(String name, int age, String email, long phoneNo, String address, String gender) {
		super();
		this.name = name;
		this.age = age;
		this.email = email;
		this.phoneNo = phoneNo;
		this.address = address;
		this.gender = gender;
	}
	
	@Override
	public String toString() {
		return "PDetails [name=" + name + ", age=" + age + ", email=" + email + ", phoneNo=" + phoneNo + ", address="
				+ address + ", gender=" + gender + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
}
