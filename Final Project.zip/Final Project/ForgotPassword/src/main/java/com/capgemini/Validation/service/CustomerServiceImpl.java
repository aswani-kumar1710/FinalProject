package com.capgemini.Validation.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.capgemini.Validation.bean.Customer;
import com.capgemini.Validation.bean.PDetails;
import com.capgemini.Validation.repo.CustomerRepo;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepo repo;

	@Autowired
	@PersistenceContext
	EntityManager entity;

	private JavaMailSender javaMailSender;

	@Autowired
	public CustomerServiceImpl(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	static Optional<Customer> list;

	public void getCustomer(int code) {

		list = repo.findById(code);
		list.get().setStatus(true);

	}

	@Override
	public void find(String email) {
		
		 
		
		List<PDetails> list1= new ArrayList<PDetails>();
		
		Query q= entity.createQuery("from PDetails");
		list1 = q.getResultList();
	
		
		
		
		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo(email);
		mail.setFrom("udykmr13@gmail.com");
		mail.setSubject("Veriification Code");
		mail.setText(" The CapStore Verification Code is"); // get the v_code from the table and give it here
		javaMailSender.send(mail);
		
		
	}

	

}
