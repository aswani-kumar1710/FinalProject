package com.capgemini.ValidationMvc.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.capgemini.ValidationMvc.bean.Customer;


@Controller
public class CustomerController {
	
		@RequestMapping("/validate")
	public Customer getproduct(@RequestParam String code)
	{
		RestTemplate rt = new RestTemplate();
		Customer c = rt.getForObject("http://localhost:9910/getvalidated?code="+code, Customer.class);
		return c;
	}
}
