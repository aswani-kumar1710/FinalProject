package com.capgemini.Validation.repo;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.Validation.bean.Customer;

@Repository
public interface CustomerRepo extends CrudRepository<Customer, Integer>{



}

