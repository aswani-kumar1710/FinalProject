package com.capgemini.Validation.service;

import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.capgemini.Validation.bean.Customer;
import com.capgemini.Validation.bean.PDetails;
import com.capgemini.Validation.repo.CustomerRepo;
import com.capgemini.Validation.repo.PDetailsRepo;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepo repo1;

	@Autowired
	private PDetailsRepo repo2;

	@Autowired
	@PersistenceContext
	EntityManager entity;

	private JavaMailSender javaMailSender;

	@Autowired
	public CustomerServiceImpl(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	static Optional<Customer> list;
	static Optional<PDetails> list1;

	public void getCustomer(int code) {

		list = repo1.findById(code);

		list.get().setStatus(true);

	}

	@Override
	public void find(String email) throws MailException {

		
		String senderEmail = email.concat("@gmail.com");
		
		list1 = repo2.findById(senderEmail);
		
		// int code = (int)(Math.random()*9000)+1000;
	//	list1.get().setCode(code);

		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo(senderEmail);
		mail.setFrom("udykmr13@gmail.com");
		mail.setSubject("Veriification Code");
		mail.setText(" The CapStore Verification Code is" +list1.get().getCode()); // get the v_code from the table and give it here
		javaMailSender.send(mail);

	}

}
